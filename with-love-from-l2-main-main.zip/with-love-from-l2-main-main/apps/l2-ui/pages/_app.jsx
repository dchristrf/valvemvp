import { useState, useEffect } from 'react'
import { ThemeProvider } from 'styled-components'
import Head from 'next/head'

import theme, { color } from '../components/theme'

import GlobalStyles from '../styles/GlobalStyles'
import { ThirdwebProvider } from '@thirdweb-dev/react';

import "../public/hot.css"
function NextApp({ Component, pageProps }) {
    const enableDarkMode = false

    const [prefersDarkMode, setPrefersDarkMode] = useState(false)
    const desiredChainId = 1;

    useEffect(() => {
        const handleDarkMode = (darkBool) => {
            setPrefersDarkMode(darkBool)
        }

        // check for dark mode
        const darkMode = window.matchMedia(
            '(prefers-color-scheme: dark)',
        ).matches

        // set dark mode boolean on mount
        handleDarkMode(darkMode)

        // add event listener to check for dark mode changes
        window
            .matchMedia('(prefers-color-scheme: dark)')
            .addEventListener('change', (e) => handleDarkMode(e.matches))
    }, [])

    const themeLight = {
        ...theme,
        color: {
            ...color.light,
            utility: {
                ...color.utility,
            },
            greyscale: color.greyscale,
        },
    }

    const themeDark = {
        ...theme,
        color: {
            ...color.dark,
        },
    }

    return (
        <ThirdwebProvider desiredChainId={desiredChainId}>
        <ThemeProvider
            theme={
                enableDarkMode // check if dark mode is enabled
                    ? prefersDarkMode // if it's enabled, check if user prefers dark mode
                        ? themeDark
                        : themeLight
                    : themeLight
            }
        >
            <Head>
                <title>The Dang Dusko Vol. 2 Mint!</title>
                <meta name="description" content="L2" />

                <meta charSet="utf-8" />
                <meta
                    name="viewport"
                    content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover"
                />

                <link rel="icon" href="/favicon.ico" type="image/x-icon" />

                <meta property="og:type" content="website" />
                <meta property="og:url" content="" />
                <meta
                    property="og:title"
                    content="The Dang Dusko Vol. 2 Mint!"
                />
                <meta
                    property="og:description"
                    content="The Dang Dusko Vol. 2 Mint!"
                />
                <meta property="og:image" content="/meta.png" />

                <meta property="twitter:card" content="summary_large_image" />
                <meta property="twitter:url" content="" />
                <meta
                    property="twitter:title"
                    content="The Dang Dusko Vol. 2 Mint!"
                />
                <meta
                    property="twitter:description"
                    content="The Dang Dusko Vol. 2 Mint!"
                />
                <meta property="twitter:image" content="/meta.png" />
            </Head>
            <GlobalStyles />
            <Component {...pageProps} />
        </ThemeProvider>
        </ThirdwebProvider>
    )
}

export default NextApp
