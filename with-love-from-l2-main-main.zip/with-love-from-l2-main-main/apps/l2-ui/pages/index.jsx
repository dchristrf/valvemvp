import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'

import Page from '../components/ui/Page'
import Layout from '../components/ui/Layout'
import Loader from '../components/ui/Loader'
import Button from '../components/ui/Button'
import Web3 from 'web3'
import Select from 'react-select'
import Text from '../components/ui/Text'
import GlobalStyles from '../styles/GlobalStyles'
import $ from 'jquery'
import { fonts } from '../helpers/fonts'
import useSWR from 'swr'
import ImageMap from "image-map";

// import {
//     useMetamask,
//     useNetwork,
//     useAddress,
//     useDisconnect,
//   } from '@thirdweb-dev/react';

import {
    useMetamask,
    useWalletConnect,
    useCoinbaseWallet,
    useNetwork,
    useAddress,
    useDisconnect,
} from '@thirdweb-dev/react'

import { ThirdwebSDK } from '@thirdweb-dev/sdk'

import styled from 'styled-components'

export default function Home() {
    const router = useRouter()
    const [claimingIDs, setClaimingIDs] = useState([])
    const connectWithCoinbaseWallet = useCoinbaseWallet()
    const connectWithMetamask = useMetamask()
    const connectWithWalletConnect = useWalletConnect()
    const disconnectWallet = useDisconnect()
    const address = useAddress()
    const network = useNetwork()
    const [balance, setBalance] = useState([])
    const [isMint, setMint] = useState(true)
    const [selectedOption, setSelectedOption] = useState(null)
    const [isTooSmall, setSize] = useState(false)
    const fetcher = (url) => fetch(url).then((res) => res.json())
    function arrayFetcher(urlArr) {
        for (let i = 0; i < balance.length; i++) {
            urlArr.push(`/api/planet/${balance[i]}`)
        }
        if (urlArr) {
            const f = (u) => fetch(u).then((r) => r.json())
            return Promise.all(urlArr.map(f))
        }
    }
    let urlArray = []
    const { data, error } = useSWR(
        balance.length > 0 ? [urlArray] : null,
        arrayFetcher,
    )

    const rpcUrl =
        'https://eth-mainnet.alchemyapi.io/v2/bi2-usfNM_1MtsEY5nxqc5DZLpZO-oEY'
    const sdk = new ThirdwebSDK(rpcUrl)

    function getClaiming(key) {
        return claimingIDs.includes(key) || false
    }

    const handleClaim = async (id) => {
        if (
            claiming.filter((obj) => {
                return obj[0] == this?.id
            }).length > 0
        )
            return
        let clam = claiming
        clam.push(id)
        setClaiming(clam)
        const response = await fetch(
            `/api/claimplanet/${id}?address=${address}`,
        ).then((b) => {
            b.text().then((c) => router.push(c))
            //window.open(b.url,"_self")
        })
    }
    const [options, setOptions] = useState([])
    const getAllNFTS = async (address) => {
        try {
            //0x33eecbf908478c10614626a9d304bfe18b78dd73
            const balancehex = await await sdk
                .getNFTCollection('0xd78a2E7aec98c15911F5F513a9e4448D721c0488')
                .balanceOf(address)
            let tokenIDsN = []
            let opt = []

            console.log(remaining)
            for (let i = 1; i < remaining; i++) {
                try {
                    const tokenIDsHex = await sdk
                        .getNFTCollection(
                            '0xd78a2E7aec98c15911F5F513a9e4448D721c0488',
                        )
                        .ownerOf(i)
                        .then((x) => {
                            if (x == address) {
                                tokenIDsN.push(i)
                                opt.push({ value: i, label: `Token ID ${i}` })
                            }
                        })
                } catch {
                    console.log('')
                }
            }
            const balancen = await balancehex.toNumber()
            if (balancen == 0 && !isMint) {
                alert('No urbits')
                router.push('https://urbit.org')
            }
            setBalance(tokenIDsN)
            setOptions(opt)
            return tokenIDsN
            // .getContract('0x33eecbf908478c10614626a9d304bfe18b78dd73')
            // .balanceOf(address)
        } catch (err) {
            console.log(err)
        }
    }

    useEffect(() => {
        if (address && !isMint) {
            getAllNFTS(address)
        }
    }, [address, isMint])

    useEffect(() => {
        console.log(data)
    }, [data])

    useEffect(() => {
        var image = { width: 100, height: 100 }

        var target = { x: 0, y: 0 }
        var pointer = $('#pointer1')

        $(window).on('load', function () {
            updatePointer()
        })

        $(window).on('resize', function () {
            updatePointer()
        })

        function updatePointer() {
            console.log('update')
            var windowWidth = $(window).width()
            var windowHeight = $(window).height()

            //if (windowWidth < 784 || windowHeight < 784) setSize(true);

            // Get largest dimension increase
            var xScale = windowWidth / image.width
            var yScale = windowHeight / image.height
            var scale
            var yOffset = 0
            var xOffset = 0

            if (xScale > yScale) {
                // The image fits perfectly in x axis, stretched in y
                scale = xScale
                yOffset = (windowHeight - image.height * scale) / 2
            } else {
                // The image fits perfectly in y axis, stretched in x
                scale = yScale
                xOffset = (windowWidth - image.width * scale) / 2
            }
            pointer.css('top', target.y * scale + yOffset)
            pointer.css('left', target.x * scale + xOffset)
        }
    }, [])

    useEffect(()=>{
        ImageMap('img[usemap]')
    },[])

    const [mintprice, setprice] = useState(0)
    const [claiming, setClaiming] = useState([])
    var [ethprice, setpriceE] = useState(0)
    var [supply, setsupply] = useState(0)
    var [remaining, setremaining] = useState(0)
    var web5 = new Web3()
    // const { height, width } = useWindowDimensions();
    web5.setProvider(
        'https://eth-mainnet.alchemyapi.io/v2/bi2-usfNM_1MtsEY5nxqc5DZLpZO-oEY',
    )
    var ABI = [
        { inputs: [], stateMutability: 'payable', type: 'constructor' },
        {
            inputs: [],
            name: 'ApprovalCallerNotOwnerNorApproved',
            type: 'error',
        },
        { inputs: [], name: 'ApprovalQueryForNonexistentToken', type: 'error' },
        { inputs: [], name: 'ApprovalToCurrentOwner', type: 'error' },
        { inputs: [], name: 'ApproveToCaller', type: 'error' },
        { inputs: [], name: 'BalanceQueryForZeroAddress', type: 'error' },
        { inputs: [], name: 'MintToZeroAddress', type: 'error' },
        { inputs: [], name: 'MintZeroQuantity', type: 'error' },
        { inputs: [], name: 'OwnerQueryForNonexistentToken', type: 'error' },
        {
            inputs: [],
            name: 'TransferCallerNotOwnerNorApproved',
            type: 'error',
        },
        { inputs: [], name: 'TransferFromIncorrectOwner', type: 'error' },
        {
            inputs: [],
            name: 'TransferToNonERC721ReceiverImplementer',
            type: 'error',
        },
        { inputs: [], name: 'TransferToZeroAddress', type: 'error' },
        { inputs: [], name: 'URIQueryForNonexistentToken', type: 'error' },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'owner',
                    type: 'address',
                },
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'approved',
                    type: 'address',
                },
                {
                    indexed: true,
                    internalType: 'uint256',
                    name: 'tokenId',
                    type: 'uint256',
                },
            ],
            name: 'Approval',
            type: 'event',
        },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'owner',
                    type: 'address',
                },
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'operator',
                    type: 'address',
                },
                {
                    indexed: false,
                    internalType: 'bool',
                    name: 'approved',
                    type: 'bool',
                },
            ],
            name: 'ApprovalForAll',
            type: 'event',
        },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: true,
                    internalType: 'contract IERC20',
                    name: 'token',
                    type: 'address',
                },
                {
                    indexed: false,
                    internalType: 'address',
                    name: 'to',
                    type: 'address',
                },
                {
                    indexed: false,
                    internalType: 'uint256',
                    name: 'amount',
                    type: 'uint256',
                },
            ],
            name: 'ERC20PaymentReleased',
            type: 'event',
        },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'previousOwner',
                    type: 'address',
                },
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'newOwner',
                    type: 'address',
                },
            ],
            name: 'OwnershipTransferred',
            type: 'event',
        },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: false,
                    internalType: 'address',
                    name: 'account',
                    type: 'address',
                },
                {
                    indexed: false,
                    internalType: 'uint16',
                    name: 'shares',
                    type: 'uint16',
                },
            ],
            name: 'PayeeAdded',
            type: 'event',
        },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: false,
                    internalType: 'address',
                    name: 'from',
                    type: 'address',
                },
                {
                    indexed: false,
                    internalType: 'uint256',
                    name: 'amount',
                    type: 'uint256',
                },
            ],
            name: 'PaymentReceived',
            type: 'event',
        },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: false,
                    internalType: 'address',
                    name: 'to',
                    type: 'address',
                },
                {
                    indexed: false,
                    internalType: 'uint256',
                    name: 'amount',
                    type: 'uint256',
                },
            ],
            name: 'PaymentReleased',
            type: 'event',
        },
        {
            anonymous: false,
            inputs: [
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'from',
                    type: 'address',
                },
                {
                    indexed: true,
                    internalType: 'address',
                    name: 'to',
                    type: 'address',
                },
                {
                    indexed: true,
                    internalType: 'uint256',
                    name: 'tokenId',
                    type: 'uint256',
                },
            ],
            name: 'Transfer',
            type: 'event',
        },
        {
            inputs: [
                { internalType: 'address', name: 'account', type: 'address' },
                { internalType: 'uint16', name: 'shares_', type: 'uint16' },
            ],
            name: 'addPayee',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'account', type: 'address' },
            ],
            name: 'addToken',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'to', type: 'address' },
                { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
            ],
            name: 'approve',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'owner', type: 'address' },
            ],
            name: 'balanceOf',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'baseURI',
            outputs: [{ internalType: 'string', name: '', type: 'string' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'cost',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'freezeSupply',
            outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'freezeURI',
            outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
            ],
            name: 'getApproved',
            outputs: [{ internalType: 'address', name: '', type: 'address' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'address[]',
                    name: 'recipients',
                    type: 'address[]',
                },
                {
                    internalType: 'uint256[]',
                    name: 'amounts',
                    type: 'uint256[]',
                },
            ],
            name: 'gift',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'owner', type: 'address' },
                { internalType: 'address', name: 'operator', type: 'address' },
            ],
            name: 'isApprovedForAll',
            outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'mainSale',
            outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'maxMint',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'maxSupply',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'uint256',
                    name: '_mintAmount',
                    type: 'uint256',
                },
            ],
            name: 'mint',
            outputs: [],
            stateMutability: 'payable',
            type: 'function',
        },
        {
            inputs: [],
            name: 'name',
            outputs: [{ internalType: 'string', name: '', type: 'string' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'owner',
            outputs: [{ internalType: 'address', name: '', type: 'address' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
            ],
            name: 'ownerOf',
            outputs: [{ internalType: 'address', name: '', type: 'address' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'uint256', name: 'index', type: 'uint256' },
            ],
            name: 'payee',
            outputs: [{ internalType: 'address', name: '', type: 'address' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'presale',
            outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'presaleCount',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [{ internalType: 'address', name: '', type: 'address' }],
            name: 'presaleList',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'address[]',
                    name: '_addresses',
                    type: 'address[]',
                },
                {
                    internalType: 'uint256[]',
                    name: '_amounts',
                    type: 'uint256[]',
                },
            ],
            name: 'presaleSet',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'address payable',
                    name: 'account',
                    type: 'address',
                },
            ],
            name: 'release',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'contract IERC20',
                    name: 'token',
                    type: 'address',
                },
                {
                    internalType: 'address payable',
                    name: 'account',
                    type: 'address',
                },
            ],
            name: 'releaseToken',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'account', type: 'address' },
            ],
            name: 'released',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'contract IERC20',
                    name: 'token',
                    type: 'address',
                },
                { internalType: 'address', name: 'account', type: 'address' },
            ],
            name: 'releasedToken',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'renounceOwnership',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'uint256', name: '_tokenId', type: 'uint256' },
                {
                    internalType: 'uint256',
                    name: '_salePrice',
                    type: 'uint256',
                },
            ],
            name: 'royaltyInfo',
            outputs: [
                { internalType: 'address', name: '', type: 'address' },
                { internalType: 'uint256', name: '', type: 'uint256' },
            ],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'from', type: 'address' },
                { internalType: 'address', name: 'to', type: 'address' },
                { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
            ],
            name: 'safeTransferFrom',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'from', type: 'address' },
                { internalType: 'address', name: 'to', type: 'address' },
                { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
                { internalType: 'bytes', name: '_data', type: 'bytes' },
            ],
            name: 'safeTransferFrom',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'operator', type: 'address' },
                { internalType: 'bool', name: 'approved', type: 'bool' },
            ],
            name: 'setApprovalForAll',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'string',
                    name: '_baseTokenURI',
                    type: 'string',
                },
            ],
            name: 'setBaseURI',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'uint256', name: '_newCost', type: 'uint256' },
            ],
            name: 'setCost',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'receiver', type: 'address' },
                {
                    internalType: 'uint96',
                    name: 'feeNumerator',
                    type: 'uint96',
                },
            ],
            name: 'setDefaultRoyalty',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [],
            name: 'setFreezeSupply',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [],
            name: 'setFreezeURI',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'uint256',
                    name: '_newMaxMintAmount',
                    type: 'uint256',
                },
            ],
            name: 'setMaxMint',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'uint256', name: 'newMax', type: 'uint256' },
            ],
            name: 'setMaxSupply',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [{ internalType: 'bool', name: '_presale', type: 'bool' }],
            name: 'setPresaleStatus',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [{ internalType: 'bool', name: '_status', type: 'bool' }],
            name: 'setSaleStatus',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'account', type: 'address' },
                { internalType: 'uint16', name: 'shares_', type: 'uint16' },
            ],
            name: 'setShares',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'account', type: 'address' },
            ],
            name: 'shares',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'showPayees',
            outputs: [
                { internalType: 'address[]', name: '', type: 'address[]' },
            ],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'showTokens',
            outputs: [
                {
                    internalType: 'contract IERC20[]',
                    name: '',
                    type: 'address[]',
                },
            ],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'bytes4', name: 'interfaceId', type: 'bytes4' },
            ],
            name: 'supportsInterface',
            outputs: [{ internalType: 'bool', name: '', type: 'bool' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'symbol',
            outputs: [{ internalType: 'string', name: '', type: 'string' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
            ],
            name: 'tokenURI',
            outputs: [{ internalType: 'string', name: '', type: 'string' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'totalReleased',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                {
                    internalType: 'contract IERC20',
                    name: 'token',
                    type: 'address',
                },
            ],
            name: 'totalReleasedToken',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'totalShares',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [],
            name: 'totalSupply',
            outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
            stateMutability: 'view',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'from', type: 'address' },
                { internalType: 'address', name: 'to', type: 'address' },
                { internalType: 'uint256', name: 'tokenId', type: 'uint256' },
            ],
            name: 'transferFrom',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [
                { internalType: 'address', name: 'newOwner', type: 'address' },
            ],
            name: 'transferOwnership',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        {
            inputs: [],
            name: 'withdraw',
            outputs: [],
            stateMutability: 'nonpayable',
            type: 'function',
        },
        { stateMutability: 'payable', type: 'receive' },
    ]
    var mintingContract = new web5.eth.Contract(
        ABI,
        '0xd78a2E7aec98c15911F5F513a9e4448D721c0488',
    )
    useEffect(() => {
        mintingContract.methods
            .cost()
            .call()
            .then((x) => {
                setprice(x / 1000000000000000000)
            })

        mintingContract.methods
            .maxSupply()
            .call()
            .then((x) => {
                setsupply(x)
            })

        mintingContract.methods
            .totalSupply()
            .call()
            .then((x) => {
                setremaining(x)
            })

        var requestOptions = {
            method: 'GET',
            redirect: 'follow',
        }

        fetch(
            'https://production.api.coindesk.com/v2/tb/price/ticker?assets=ETH',
            requestOptions,
        )
            .then((response) => response.json())
            .then((result) => {
                setpriceE(result.data.ETH.ohlc.c)
            })
            .catch((error) => console.log('error', error))
    }, [])

    if (isMint) {
        return (
            <div
                style={{
                    backgroundColor: 'black',
                    height: '100vh',
                    width: '100vw',
                    margin: 'auto',
                }}
            >
                <CenteredDiv>
                    <img
                        src="Mintpage.png"
                        usemap="#image-map"
                        width="3932px"
                        height="3932px"
                        style={{ maxWidth: "100%", maxHeight: "100%", height: "100%"}}
                    />
                    <map name="image-map" id='image-map'>
    <area target="" alt="Mint" title="Mint" onClick={async () => {
                            if (window.ethereum) {
                                await window.ethereum.request({
                                    method: 'eth_requestAccounts',
                                })
                                window.web3 = new Web3(window.ethereum)
                                var cont = new window.web3.eth.Contract(
                                    ABI,
                                    '0xd78a2E7aec98c15911F5F513a9e4448D721c0488',
                                )
                                var acc = await window.web3.eth.getAccounts()
                                var account = acc[0]
                                cont.methods
                                    .mint(1)
                                    .send(
                                        {
                                            from: account,
                                            value:
                                                mintprice * 1000000000000000000,
                                        },
                                        function (err, res) {
                                            if (err) {
                                                return
                                            }
                                            console.log(
                                                'Hash of the transaction: ' +
                                                    res,
                                            )
                                        },
                                    )
                                return true
                            } else {
                                alert("No ethereum wallet detected")
                            }
                        }} coords="3329,981,399" shape="circle" style={{cursor: "pointer"}}/>
    <area target="" alt="Claim" title="Claim" style={{cursor: "pointer"}} coords="3334,2186,421" shape="circle" onClick={()=>setMint(false)}/>
    <area target="_blank" alt="Opensea" title="Opensea" href="https://opensea.io/collection/dusko" coords="42,233,549,393" shape="rect"/>
    <area target="_blank" alt="Etherscan" title="Etherscan" href="https://etherscan.io/address/0xd78a2e7aec98c15911f5f513a9e4448d721c0488" coords="594,227,1109,390" shape="rect"/>
</map>
                    {/* <div
                        style={{
                            alignContent: 'center',
                            justifyContent: 'center',
                            display: 'flex',
                            cursor: 'pointer',
                        }}
                        onClick={async () => {
                            if (window.ethereum) {
                                await window.ethereum.request({
                                    method: 'eth_requestAccounts',
                                })
                                window.web3 = new Web3(window.ethereum)
                                var cont = new window.web3.eth.Contract(
                                    ABI,
                                    '0xd78a2E7aec98c15911F5F513a9e4448D721c0488',
                                )
                                var acc = await window.web3.eth.getAccounts()
                                var account = acc[0]
                                cont.methods
                                    .mint(1)
                                    .send(
                                        {
                                            from: account,
                                            value:
                                                mintprice * 1000000000000000000,
                                        },
                                        function (err, res) {
                                            if (err) {
                                                return
                                            }
                                            console.log(
                                                'Hash of the transaction: ' +
                                                    res,
                                            )
                                        },
                                    )
                                return true
                            }
                        }}
                    >
                        <img src="/mint.jpeg" style={{ height: '20vw' }}></img>
                    </div>
                    <br></br>
                    <div
                        style={{
                            fontFamily: `${fonts.daisywheel}`,
                            color: 'green',
                            textAlign: 'center',
                            fontSize: '1.5rem',
                        }}
                    >
                        Mint Price: {mintprice} ETH (
                        {(mintprice * ethprice).toFixed(2)} USD)
                        <br />
                        <br />
                        Total Supply: {supply}
                        <br />
                        <br />
                        Remaining: {supply - remaining}
                    </div>
                    <br />
                    <br />
                    <div
                        style={{
                            alignContent: 'center',
                            justifyContent: 'center',
                            display: 'flex',
                        }}
                    >
                        <Button
                            onClick={() =>
                                router.push(
                                    'https://opensea.io/collection/dusko',
                                )
                            }
                        >
                            View on Opensea
                        </Button>
                        <Button
                            onClick={() =>
                                router.push(
                                    'https://etherscan.io/address/0xd78a2e7aec98c15911f5f513a9e4448d721c0488',
                                )
                            }
                        >
                            View on Etherscan
                        </Button>
                        <Button onClick={() => setMint(false)}>
                            Redeem Urbit Planet
                        </Button>
                    </div>
                    <br /> */}
                </CenteredDiv>
            </div>
        )
    }

    if (address) {
        if (isTooSmall) return <div>Please use a bigger screen.</div>

        if (!data || data?.length <= 0)
            return (
                <Page id="L2">
                    <Layout height={'100vh'} width={'100vw'} center>
                        <Loader></Loader>{' '}
                    </Layout>
                </Page>
            )

        return (
            <div
                style={{
                    backgroundImage: 'url(/background.jpeg)',
                    height: '100%',
                    backgroundPosition: 'center',
                    backgroundRepeat: 'no-repeat',
                    backgroundSize: 'contain',
                    backgroundColor: 'black',
                }}
                className="background"
            >
                <Layout height={'100vh'} width={'100vw'} center>
                    <div
                        style={{
                            marginRight: '50px',
                            marginTop: '560px',
                            position: 'fixed',
                            color: 'green',
                            textAlign: 'center',
                        }}
                        id="pointer1"
                    >
                        {' '}
                        <Select
                            defaultValue={selectedOption}
                            onChange={setSelectedOption}
                            options={options}
                        />
                        {data.filter((obj) => {
                            return obj[0]?.TokenID == selectedOption?.value
                        })?.length > 0 ? (
                            'Claimed: ' +
                            data.filter((obj) => {
                                return obj[0]?.TokenID == selectedOption?.value
                            })[0][0]?.inviter
                        ) : claiming.filter((obj) => {
                              return obj[0] == selectedOption?.value
                          }).length > 0 ? (
                            'Claiming...'
                        ) : (
                            <Button
                                onClick={() => {
                                    // let x = claimingIDs;
                                    // x.push(balance[index])
                                    // setClaimingIDs(x);
                                    handleClaim(selectedOption.value)
                                }}
                            >
                                Claim
                            </Button>
                        )}
                    </div>
                    {/* <div>
                        Address: {address}
                        <Button onClick={disconnectWallet}>Disconnect</Button>
                        <br />
                        {balance.map((token, index) => (
                            <div>
                                {token}{' '}
                                {data[index]?.length > 0 ? (
                                    'Claimed: ' + data[index][0].inviter
                                ) : getClaiming(balance[index]) ? (
                                    'Claiming...'
                                ) : (
                                    <button
                                        onClick={() => {
                                            // let x = claimingIDs;
                                            // x.push(balance[index])
                                            // setClaimingIDs(x);
                                            handleClaim(balance[index])
                                        }}
                                    >
                                        Claim
                                    </button>
                                )}
                            </div>
                        ))}
                    </div> */}
                </Layout>
            </div>
        )
    }

    // If no wallet is connected, show connect wallet options

    return (
        <Page id="L2">
            <Layout height={'100vh'} width={'100vw'} center>
                {/* <Loader /> */}
                <div>
                    <Button onClick={() => connectWithCoinbaseWallet()}>
                        Connect Coinbase Wallet
                    </Button>
                    <Button onClick={() => connectWithMetamask()}>
                        Connect MetaMask
                    </Button>
                    <Button onClick={() => connectWithWalletConnect()}>
                        Connect WalletConnect
                    </Button>
                </div>
            </Layout>
        </Page>
    )
}

const CenteredDiv = styled.div`
    position: absolute;
    left: 50%;
    top: 50%;
    -webkit-transform: translate(-50%, -50%);
    transform: translate(-50%, -50%);
`
