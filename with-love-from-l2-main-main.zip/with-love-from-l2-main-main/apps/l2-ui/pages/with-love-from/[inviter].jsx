/* eslint-disable no-underscore-dangle */
import { useContext, useEffect, useState } from 'react'
import styled, { css, ThemeContext } from 'styled-components'
import { useRouter } from 'next/router'
import useSWR from 'swr'
// import { useWindowWidth } from '@react-hook/window-size'

import { bp, bpR } from '../../helpers/breakpoints'

import Page from '../../components/ui/Page'
import Layout from '../../components/ui/Layout'
import Loader from '../../components/ui/Loader'
import Text from '../../components/ui/Text'

import Sigil from '../../components/Sigil'
import SVG from '../../components/SVG'
import Button from '../../components/ui/Button'

// CMS
const fetcher = (url) => fetch(url).then((res) => res.json())

export default function Home() {
    const [claiming, setClaiming] = useState(null)
    const router = useRouter()
    const { inviter } = router.query
    const themeContext = useContext(ThemeContext)
    const { data, error } = useSWR(`/api/planets/${inviter}`, fetcher)

    useEffect(() => {
        // if route doesn't exist, redirect to https://urbit.org
        if (data?.length === 0) {
            //router.push('https://urbit.org')
        }
    }, [router, data])

    const handleClaim = async ({ url, id }) => {
        if (!claiming) {
            setClaiming(id)
            const response = await fetch(`/api/claim/${id}`)
            const responseData = await response.json()

            const claimed = responseData.fields._claimedBool
            if (claimed === 1) {
                router.push(url)
                setClaiming(false)
            } else {
                console.log('Something went wrong 😔')
            }
        }
    }

    if (!data)
        return (
            <Layout height={'100vh'} width={'100vw'} center>
                <Loader />
            </Layout>
        )
    if (error)
        return (
            <Layout height={'100vh'} width={'100vw'} center>
                <div>Error</div>
            </Layout>
        )

    return (
        <Page id="L2" title={inviter}>
            <Layout height={'100vh'} width={'100vw'} overflowY>
                <CenterContainer>
                    <RotateContainer>
                        <Text h2>
                            <GraphicContainer>
                                <Text daisywheel fontSize={'2.5rem'}>
                                    {inviter}
                                </Text>{' '}
                                is inviting you to a new internet
                                <Stars>
                                    <SVG
                                        stars
                                        stroke={themeContext.color.main}
                                        fill={themeContext.color.background}
                                    />
                                </Stars>
                            </GraphicContainer>
                        </Text>
                        <br />
                        <br />
                        <Text h2 daisywheel>
                            <Poem>
                                A planet is your{' '}
                                <L2Span
                                    href="https://urbit.org/understanding-urbit/urbit-id"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Urbit ID
                                </L2Span>{' '}
                                and a key
                                <br />
                                To a network totally free
                                <br />
                                Of MEGACORP and algorithms
                                <br />
                                <ol>
                                    <li>Claim your planet</li>
                                    <li>
                                        Boot your planet with
                                        <br />
                                        <ul>
                                            <li>
                                                <L2Span
                                                    href="https://urbit.org/using/running/port"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                >
                                                    Port
                                                </L2Span>
                                                , free & easy, host your urbit
                                                locally on your computer
                                            </li>
                                            <li>
                                                A{' '}
                                                <L2Span
                                                    href="https://urbit.org/using/running/hosting"
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                >
                                                    DigitalOcean Droplet
                                                </L2Span>
                                                , DIY cloud hosting
                                            </li>
                                        </ul>
                                    </li>
                                </ol>
                                <br />
                                Forever yours
                            </Poem>
                        </Text>
                        <br />
                        <br />
                        <br />
                        <PlanetContainer>
                            <Heart1>
                                <SVG
                                    heart
                                    stroke={themeContext.color.main}
                                    fill={themeContext.color.background}
                                />
                            </Heart1>

                            <Heart2>
                                <SVG
                                    heart
                                    alt
                                    stroke={themeContext.color.main}
                                    fill={themeContext.color.background}
                                />
                            </Heart2>
                            {data.map((planet) => (
                                <Planet
                                    key={planet.Planet}
                                    claimed={planet._claimedBool}
                                >
                                    {/* <Sigil
                                        class="sigil"
                                        patp={planet.Planet}
                                        colors={[
                                            themeContext.color.background,
                                            themeContext.color.main,
                                        ]}
                                        // size={40}
                                    /> */}
                                    <Layout
                                        width={'100%'}
                                        center
                                        marginBottom={'1rem'}
                                    >
                                        <Text source bold>
                                            {planet.Planet}
                                        </Text>
                                    </Layout>
                                    <Layout width={'100%'} center>
                                        <Button
                                            onClick={() => {
                                                handleClaim({
                                                    url: planet[
                                                        'Invite URL (Prod)'
                                                    ],
                                                    id: planet.id,
                                                })
                                            }}
                                            disabled={planet._claimedBool === 1}
                                        >
                                            {planet._claimedBool === 0
                                                ? claiming === planet.id
                                                    ? 'Claiming...'
                                                    : 'Claim'
                                                : 'Claimed'}
                                        </Button>
                                    </Layout>
                                </Planet>
                            ))}
                        </PlanetContainer>
                        <br />
                    </RotateContainer>
                </CenterContainer>
            </Layout>
        </Page>
    )
}

const CenterContainer = styled.div`
    width: 100%;
    height: 100%;

    @media (min-width: ${bp.md}) {
        display: flex;
        justify-content: center;
        align-items: center;
    }
`

const RotateContainer = styled.div`
    width: 100%;
    padding: 4rem 5%;
    overflow: hidden;
    @media (min-width: ${bp.md}) {
        transform: rotate(1deg);
        width: 500px;
        padding: unset;

        overflow: visible;
    }
`

const PlanetContainer = styled.div`
    /* width: 600px; */
    display: flex;
    position: relative;
    flex-wrap: wrap;
`

const claimedStyle = css`
    opacity: 0.2;
    * {
        pointer-events: none !important;
    }
`

const Planet = styled.div`
    margin: 0.25rem;
    ${({ claimed }) => (claimed === 1 ? claimedStyle : '')}
`

const Poem = styled.div`
    display: block;
    position: relative;
    width: fit-content;
`

const L2Span = styled.a`
    -webkit-text-stroke: #000;
    background-color: #00ff00;
    color: #000;
`

const GraphicContainer = styled.div`
    display: block;
    position: relative;
    width: fit-content;
`

const Stars = styled.div`
    position: absolute;
    top: -50%;
    right: -10%;
    width: 3rem;
`

const Heart1 = styled.div`
    position: absolute;
    bottom: -20%;
    left: -20%;
    width: 6.5rem;
    transform: rotate(4deg);
`

const Heart2 = styled.div`
    position: absolute;
    top: -20%;
    right: -10%;
    width: 6.5rem;
    transform: rotate(-3deg);
`
