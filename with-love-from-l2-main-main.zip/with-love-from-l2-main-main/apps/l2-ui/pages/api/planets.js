// fetch planets from https://airtable.com/appDqS5PZGbVNphXN/tblxp1cq38sFmXaau/viw1yK2Y4R1kowz3F?blocks=hide

// these keys stay server side
const AIRTABLE_BASE = 'appDqS5PZGbVNphXN';
const AIRTABLE_API_KEY = 'keyZTtI0FG0Isoma4';
const AIRTABLE_VIEW = 'App';

export default async function handler(req, res) {
  const data = [];
  const response = await fetch(
    `https://api.airtable.com/v0/${AIRTABLE_BASE}/Invites?maxRecords=10&view=${AIRTABLE_VIEW}`,
    {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AIRTABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
    },
  );
  const rawData = await response.json();
  rawData.records.forEach((record) => {
    data.push(record.fields);
  });

  res.status(200).json(data);
}
