// fetch planets from https://airtable.com/appDqS5PZGbVNphXN/tblxp1cq38sFmXaau/viw1yK2Y4R1kowz3F?blocks=hide

// these keys stay server side
const AIRTABLE_BASE = 'appqIq66hdO9ocfe6';
const AIRTABLE_API_KEY = 'keyN8htAHxFgd7k7x';
const AIRTABLE_VIEW = 'App';

const filter = (param) => {
  return encodeURIComponent(`{TokenID} = ''`);
};

export default async function handler(req, res) {
  const { inviter } = req.query;
  console.log(req.query)

  const urlEncodedFilter = filter(inviter);

  const data = [];
  const response = await fetch(
    `https://api.airtable.com/v0/${AIRTABLE_BASE}/Invites?filterByFormula=${urlEncodedFilter}&maxRecords=3&view=${AIRTABLE_VIEW}`,
    {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${AIRTABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
    },
  );
  const rawData = await response.json();
  const link = rawData.records[0].fields.InviteLink;

  const responses = await fetch('https://api.airtable.com/v0/appqIq66hdO9ocfe6/Invites', {
    method: 'PATCH',
    headers: {
        'Authorization': `Bearer ${AIRTABLE_API_KEY}`,
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
  "records": [
    {
      "id": rawData.records[0].id,
      "fields": {
        "TokenID": req.query.inviter,
        "Wallet": req.query.address
      }
    },

  ]
})

});
const raw = await responses.json();
console.log("y")
console.log(raw.fields);


  res.send(link);
}
