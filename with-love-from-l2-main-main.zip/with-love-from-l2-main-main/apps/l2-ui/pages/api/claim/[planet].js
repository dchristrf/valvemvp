// fetch planets from https://airtable.com/appDqS5PZGbVNphXN/tblxp1cq38sFmXaau/viw1yK2Y4R1kowz3F?blocks=hide

// these keys stay server side
const AIRTABLE_BASE = 'appqIq66hdO9ocfe6';
const AIRTABLE_API_KEY = 'keyN8htAHxFgd7k7x';

export default async function handler(req, res) {
  // get planet that is being claimed from query
  const { planet } = req.query;
  const id = planet;

  // console log the id for server side debugging if needed
  console.log(id);

  // update the planet on airtable to mark as claimed via record ID
  const response = await fetch(
    `https://api.airtable.com/v0/${AIRTABLE_BASE}/Invites/${id}`,
    {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${AIRTABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fields: {
          Status: 'Claimed in L2 giveaway',
        },
      }),
    },
  );
  const data = await response.json();
    console.log(data)
  // send back updated data
  res.status(200).json(data);
}
