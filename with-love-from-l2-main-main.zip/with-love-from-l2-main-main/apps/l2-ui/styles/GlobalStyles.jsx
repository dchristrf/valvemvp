import { createGlobalStyle } from 'styled-components'
import { fonts, fontFiles } from '../helpers/fonts'

const GlobalStyles = createGlobalStyle`
    // Fonts

    @font-face {
        font-family: "inter-regular";
        src: url("/${fontFiles.inter.regular.woff2}") format("woff2");
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: "inter-semi-bold";
        src: url("/${fontFiles.inter.semiBold.woff2}") format("woff2"),
        url("/${fontFiles.inter.semiBold.woff}") format("woff");
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: "source-code-regular";
        src: url("/${fontFiles.sourceCodePro.regular.woff2}") format("woff2");
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: "source-code-bold";
        src: url("/${fontFiles.sourceCodePro.bold.woff2}") format("woff2");
        font-weight: normal;
        font-style: normal;
    }

    @font-face {
        font-family: "daisywheel";
        src: url("/${fontFiles.daisywheel.otf}") format("opentype");
        font-weight: normal;
        font-style: normal;
    }

    // Defaults
    * {
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-rendering: optimizeLegibility;
        -webkit-tap-highlight-color: transparent;
    }

    html, body {
        -webkit-text-size-adjust: 100%;
        min-height: 100vh;
        // ios mobile viewport bug fix
        min-height: -webkit-fill-available;

        padding: 0;
        margin: 0;
        font-family: ${fonts.inter.regular};
    }

    body {
        font-size: ${({ theme }) =>
            theme.type.baseFontSize ||
            14}px; // ⚠️ this ends up equalling "1rem" in our app
        color: ${({ theme }) => theme.color.main};
        background-color: ${({ theme }) => theme.color.background};

        & * {
            ::selection {
                color: inherit;
                background: ${({ theme }) => theme.color.highlight};
            }
        }

        overflow-x: hidden;

        & > * {
            overflow-x: unset;
        }
    }

    * {
        box-sizing: border-box;
    }

    html.touch *:hover {
        all: unset !important;
        pointer-events: none !important;
    }

    a {
        text-decoration: none;
        cursor: pointer;
        outline: 0;
        color: ${({ theme }) => (theme ? theme.color.main : 'initial')};
    }

    background {
        /* Full height */
        height: 100%; 
    
        /* Center and scale the image nicely */
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }

`

export default GlobalStyles
