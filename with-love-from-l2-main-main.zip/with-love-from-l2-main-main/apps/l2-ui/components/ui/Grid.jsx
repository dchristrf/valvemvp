import styled from 'styled-components'

// The Grid component is built using CSS grid.

// The "area" prop to determine how many elements wide the grid should be.
// ex: Pass ". ." into area for 2x item wide grid, ". . ." for 3x, etc.

const Grid = ({ area, children, gap, rowGap, colGap }) => {
    return (
        <GridContainer
            area={area}
            rowGap={rowGap} // row gap
            colGap={colGap} // column gap
            gap={gap}
            // "gap" is for both row and column gap:
            // overrides both rowGap and colGap if present
            // if passed without a string, uses `1em 1em`
        >
            {children}
        </GridContainer>
    )
}

export default Grid

const determineGap = ({ gap, rowGap, colGap }) => {
    if (gap) {
        if (gap === true) {
            return `1em 1em`
        }
        return `${gap} ${gap}`
    }
    if (rowGap && colGap) {
        return `${rowGap} ${colGap}`
    }
    if (rowGap) {
        return `${rowGap} 0`
    }
    if (colGap) {
        return `0 ${colGap}`
    }
    return '0 0'
}

export const GridContainer = styled.div`
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 1fr;
    grid-auto-columns: 1fr;
    grid-auto-rows: 1fr;
    gap: ${(props) => determineGap(props)};
    grid-auto-flow: row;
    align-items: end;
    grid-template-areas: '${({ area }) => area}';
    width: 100%;
    position: relative;
`
