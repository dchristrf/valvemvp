import styled, { css } from 'styled-components'

import { bp } from '../../helpers/breakpoints'
import { type } from '../../helpers/type'
import { fonts } from '../../helpers/fonts'

const Text = ({
    p,
    h1,
    h2,
    h3,
    bold,
    // italic,

    inter,
    source,
    daisywheel,

    fontSize, // override font size
    indent, // indent paragraphs
    linebreak, // add a line break after each paragraph (paragraphs only)
    columns,
    gap, // column-gap
    orphans,
    widows,

    children,
}) => {
    const styleProps = {
        bold,
        inter,
        source,
        daisywheel,
        color,
        fontSize,
        indent,
        linebreak, // paragraphs only
        columns,
        gap,
        orphans,
        widows,
    }

    if (p) {
        // parapraphs
        return (
            <TextElementParagraph {...styleProps}>
                {children.map((child, paragraphNumber) => {
                    return <p key={paragraphNumber}>{child}</p>
                })}
            </TextElementParagraph>
        )
    }

    // headings
    if (h1) {
        return <TextElementH1 {...styleProps}>{children}</TextElementH1>
    }
    if (h2) {
        return <TextElementH2 {...styleProps}>{children}</TextElementH2>
    }
    if (h3) {
        return <TextElementH3 {...styleProps}>{children}</TextElementH3>
    }

    return <TextElement {...styleProps}>{children}</TextElement>
}

export default Text

const fontStyle = css`
    ${({ source }) => source && `font-family: ${fonts.sourceCodePro.regular};`}

    ${({ source, bold }) =>
        source && bold && `font-family: ${fonts.sourceCodePro.bold};`}

    ${({ daisywheel }) => daisywheel && `font-family: ${fonts.daisywheel};`}
`

const columnStyle = css`
    white-space: pre-line;

    column-count: ${({ columns }) => columns};
    column-gap: ${({ gap }) => gap};
    column-width: auto;

    orphans: ${({ orphans }) => (orphans ? orphans : 'initial')}; // initial = 2
    widows: ${({ widows }) => (widows ? widows : 'initial')}; // initial = 2
`

const baseTextStyles = css`
    ${type(1, ({ fontSize }) => fontSize || false)}
    ${({ columns }) => columns && columnStyle};
    text-indent: ${({ indent }) => (indent ? indent : '0')};
    ${fontStyle};
`

const unsetHeadingStyles = css`
    font-weight: unset;
    margin: 0;
`

const TextElement = styled.span`
    ${baseTextStyles}
    ${({ fontSize }) => (fontSize ? type(1, fontSize) : type(1))}
`

const TextElementParagraph = styled.div`
    // the same as TextElement, but as a <p> element
    ${baseTextStyles}

    & > p {
        margin: 0;
        margin-bottom: ${({ linebreak }) => (linebreak ? '1em' : '0')};

        &:last-of-type {
            margin-bottom: 0;
        }
    }
`

const TextElementH1 = styled.h1`
    ${baseTextStyles}
    ${unsetHeadingStyles}
    ${({ fontSize }) => (fontSize ? type(1, fontSize) : type(4))}
    line-height: 0.9em;
`

const TextElementH2 = styled.h2`
    ${baseTextStyles}
    ${unsetHeadingStyles}
    ${({ fontSize }) => (fontSize ? type(1, fontSize) : type(2))}
    line-height: 0.9em;
`

const TextElementH3 = styled.h3`
    ${baseTextStyles}
    ${unsetHeadingStyles}
    ${({ fontSize }) => (fontSize ? type(1, fontSize) : type(1.25))}
    line-height: 0.9em;
`
