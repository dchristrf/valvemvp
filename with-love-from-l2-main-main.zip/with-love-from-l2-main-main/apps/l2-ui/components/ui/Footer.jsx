/* eslint-disable react/no-this-in-sfc */
import { useState, useEffect, useContext, useRef } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/router'
import styled, { css, ThemeContext } from 'styled-components'
import { useWindowWidth } from '@react-hook/window-size'

import Layout from './Layout'
import Text from './Text'

import { bp, bpR } from '../../helpers/breakpoints'

const Footer = () => {
    const themeContext = useContext(ThemeContext)
    const [screenWidth, setScreenWidth] = useState(useWindowWidth())

    return (
        <Layout
            padding={'6rem 2rem'}
            backgroundColor={themeContext.color.background}
        >
            <Text p columns={8} gap={'2rem'}>
                <Text>
                    <a
                        // href={}
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Link
                    </a>
                </Text>
                <Text>
                    <a
                        // href={}
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        Link
                    </a>
                </Text>
            </Text>
        </Layout>
    )
}

export default Footer
