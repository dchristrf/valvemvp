import styled, { css } from 'styled-components'
import { boxflex } from '../../helpers/style'

const Button = ({
    href,
    children,
    onClick,

    // styles
    disabled,
    fullWidth,
    uppercase,
    padding,
    margin,
}) => {
    const styleProps = {
        disabled,
        fullWidth,
        uppercase,
        padding,
        margin,
    }
    return (
        <Btn
            {...styleProps}
            href={href}
            target="_blank"
            rel="noopener"
            onClick={onClick}
        >
            {children}
        </Btn>
    )
}
export default Button

const buttonStyles = css`
    font-family: 'inter-semi-bold';

    display: inline-block;

    font-size: 1em;

    /* background-color: ${({ theme }) => theme.color.greyscale[0]}; */
    background-color: #00ff00;

    color: ${({ theme }) => theme.color.main};

    min-width: ${({ fullWidth }) => (fullWidth ? '0' : 'fit-content')};
    width: ${({ fullWidth }) => (fullWidth ? '100%' : 'fit-content')};
    padding: ${({ padding }) => (padding ? padding : '0.5em 1em 0.6em')};
    margin: ${({ margin }) => (margin ? margin : '0px 0px')};

    text-transform: ${({ uppercase }) =>
        uppercase ? 'uppercase' : 'capitalize'};

    border: ${({ theme }) => `3px solid ${theme.color.greyscale[0]}`};

    border-radius: 0.5rem;

    cursor: pointer;
    text-align: center;
    white-space: nowrap;

    transition: ${({ theme }) => theme.transition};
`

const focusStyles = css`
    border: ${({ theme }) => `3px solid ${theme.color.greyscale[8]}`};
`

const disabledButtonStyle = css`
    cursor: not-allowed;
    background-color: ${({ theme }) => theme.color.main};
    color: ${({ theme }) => theme.color.background};
`

const Btn = styled.div`
    ${buttonStyles}

    & {
        // using "&" here along with the styles above ^ forces loading - might be related to swc
        ${buttonStyles}

        ${({ disabled }) => disabled && disabledButtonStyle}
    }

    &:focus {
        ${focusStyles}
    }
`
