// This component is designed to wrap around something.
// It can be used as a full page overlay or a specified height/width modal.

// The outer div is always set to 100vw/100vh.
// The inner div can be passed custom height/width params

import styled from 'styled-components'
import { useState, useRef, useEffect, useCallback } from 'react'
import { boxflex } from '../../helpers/style'

const Overlay = ({
    children,
    label, // label for overlay trigger

    // styles
    bgColorOuter, // string; uses theme.color.background as default
    bgColorInner, // string; uses theme.color.background as default
    width, // string; 100% as default
    height, // string; 100% as default
    paddingOuter, // string; defaults to 0
    marginOuter, // string; defaults to 0
    paddingInner, // string; defaults to 1rem
    marginInner, // string; defaults to 0
    border, // string; default none

    textAlign, // string; left, right

    blur, // string if passed, otherwise 5px if true

    // positioning
    fixed, // boolean; default false, 'fixed' if true
    top,
    right,
    bottom,
    left,
}) => {
    const [showOverlay, setShowOverlay] = useState(false)

    const overlayRef = useRef()

    const closeOverlay = (e) => {
        if (overlayRef.current === e.target) {
            setShowOverlay(false)
        }
    }
    const escPress = useCallback(
        (e) => {
            if (e.key === 'Escape' && showOverlay) {
                setShowOverlay(false)
            }
        },
        [setShowOverlay, showOverlay],
    )

    useEffect(() => {
        document.addEventListener('keydown', escPress)
        return () => document.removeEventListener('keydown', escPress)
    }, [escPress])

    const blurValue = blur ? (blur === true ? '5px' : blur) : 0

    const styleProps = {
        bgColorOuter,
        bgColorInner,
        width,
        height,
        paddingOuter,
        marginOuter,
        paddingInner,
        marginInner,
        border,
        blur,
        blurValue,
        textAlign,
        fixed,
        top,
        right,
        bottom,
        left,
    }
    return (
        <>
            <Open onClick={setShowOverlay}>{label}</Open>

            {showOverlay && (
                <OverlayOuter
                    {...styleProps}
                    ref={overlayRef}
                    onClick={closeOverlay}
                >
                    <OverlayInner {...styleProps}>
                        <Close
                            {...styleProps}
                            onClick={() => setShowOverlay((prev) => !prev)}
                        >
                            Close
                        </Close>
                        <InnerContainer {...styleProps}>
                            {children}
                        </InnerContainer>
                    </OverlayInner>
                </OverlayOuter>
            )}
        </>
    )
}

export default Overlay

const Open = styled.span`
    cursor: pointer;
`

const OverlayOuter = styled.div`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    right: 0px;
    bottom: 0px;
    background-color: ${({ bgColorOuter, theme }) =>
        bgColorOuter ? bgColorOuter : theme.color.background};
    padding: ${({ paddingOuter }) => (paddingOuter ? paddingOuter : '0 0')};
    margin: ${({ marginOuter }) => (marginOuter ? marginOuter : '0 0')};
    ${({ blur, blurValue }) =>
        blur && blurValue && `backdrop-filter: blur(${blurValue})`};
    overflow-y: scroll;
    z-index: 20;

    ${({ fixed }) => fixed && boxflex()};
`

const OverlayInner = styled.div`
    background-color: ${({ bgColorInner, theme }) =>
        bgColorInner ? bgColorInner : theme.color.background};
    height: ${({ height }) => (height ? height : '100%')};
    max-width: ${({ width }) => (width ? width : '100%')};
    min-width: auto;
    width: 100%;
    overflow: scroll;
    padding: ${({ paddingInner }) => (paddingInner ? paddingInner : '1rem')};
    margin: ${({ marginInner }) => (marginInner ? marginInner : '0 0')};
    border: ${({ border, theme }) =>
        border ? `1px solid${theme.color.main}` : 'none'};

    position: ${({ fixed }) => (fixed ? 'fixed' : 'fixed')};
    top: ${({ top }) => (top ? top : 'unset')};
    right: ${({ right }) => (right ? right : 'unset')};
    bottom: ${({ bottom }) => (bottom ? bottom : 'unset')};
    left: ${({ left }) => (left ? left : 'unset')};

    text-align: ${({ textAlign }) => (textAlign ? textAlign : 'left')};
`

const Close = styled.span`
    cursor: pointer;
    margin-left: 2rem;
    margin-bottom: 1rem;
    float: right;
    color: ${({ theme }) => theme.color.main};
`

const InnerContainer = styled.div`
    margin: ${({ marginInner }) => (marginInner ? marginInner : '0px')};
`
