import { useContext } from 'react'
import styled, { ThemeContext } from 'styled-components'
import Head from 'next/head'

const Page = ({ title, description, children, themeColor }) => {
    const themeContext = useContext(ThemeContext)
    return (
        <PageContainer>
            <Head>
                <title>
                    {/* check for @patp */}
                    {title
                        ? `${title} is inviting you to a new internet`
                        : 'Tlon is inviting you to a new internet'}
                </title>
                <meta
                    name="description"
                    content={description ? description : 'Claim a planet'}
                />
                <meta
                    name="viewport"
                    content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover"
                />
                <link rel="icon" href="/favicon.ico" type="image/x-icon" />
                <meta
                    name="theme-color"
                    content={
                        themeColor ? themeColor : themeContext.color.background
                    }
                    // themeColor sets uses the `theme-color` meta tag to change the tab bar background and over-scroll area in macOS and iPadOS, and the status bar in iOS 15+
                    // https://developer.apple.com/documentation/safari-release-notes/safari-15-release-notes
                    // if no `themeColor` prop is provided, the default is `theme.color.background` (defined in `theme.js`)
                />
            </Head>
            {children}
        </PageContainer>
    )
}

export default Page

const PageContainer = styled.div`
    width: 100%;
`
