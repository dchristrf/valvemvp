// eslint-disable-next-line import/no-named-default
import { default as MarqueeBanner } from 'react-fast-marquee'
import styled from 'styled-components'
import { bp } from '../../helpers/breakpoints'

// How to use this component ⤵

// This component uses the react-fast-marquee -> See here for all props: https://github.com/justin-chu/react-fast-marquee#readme

const Marquee = ({
    children,
    play,
    fontSize,
    pauseOnHover,
    pauseOnClick,
    direction,
    speed,
    delay,
    loop,
    gap,
}) => {
    return (
        <MarqueeContainer fontSize={fontSize} gap={gap}>
            <MarqueeBanner
                play={play}
                pauseOnHover={pauseOnHover}
                pauseOnClick={pauseOnClick}
                direction={direction}
                speed={speed}
                delay={delay}
                loop={loop}
                gradient={false}
            >
                {children}
            </MarqueeBanner>
        </MarqueeContainer>
    )
}
export default Marquee

const MarqueeContainer = styled.div`
    color: ${({ theme }) => theme.color.main};

    font-size: ${({ fontSize }) => (fontSize ? fontSize : '1em')};

    .marquee {
        margin-right: ${({ gap }) => (gap ? gap : '0')};
    }
`
