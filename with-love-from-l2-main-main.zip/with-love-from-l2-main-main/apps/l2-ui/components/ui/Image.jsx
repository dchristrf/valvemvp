import { useCallback, useState } from 'react'
import styled from 'styled-components'
import imageTransformations from '../../helpers/imageTransformations'

// How to use this component ⤵

// You can use this component like an HTML img element,
// by passing in the src, width, height, and alt attributes
// ex:
// <Image src="http://placeholder.com/350x150.png" width="350" height="150" alt="test" />

// Notes:
// - all props are optional
// - ⚠️ the width and height props MUST be numbers

//
//                                                                                       █
//                                                                      █              ██
//  ██                                                                 ███             ██
//  ██                                                                  █              ██
//   ██    ███           ███  ████   ██   ████                 ████                    ██
//    ██    ███    ███    ████ ████ █ ██    ███  █            █ ████ ████       ████   ██  ███
//    ██     ███  █ ███    ██   ████  ██     ████            ██  ████  ███     █ ███  ███ █ ███
//    ██      ██ █   ███   ██         ██      ██            ████        ██    █   ████ ███   █
//    ██      ████    ███  ██         ██      ██              ███       ██   ██        ██   █
//    ██      ██████████   ██         ██      ██                ███     ██   ██        ██  █
//    ██      █████████    ██         ██      ██                  ███   ██   ██        ██ ██
//    ██      █ ██         ██         ██      ██             ████  ██   ██   ██        ██████
//     ███████  ████    █  ███         █████████            █ ████ █    ██   ███     █ ██  ███
//      █████    ███████    ███          ████ ███              ████     ███ █ ███████  ██   ███ █
//                █████                        ███                       ███   █████    ██   ███
//                                      █████   ███
//                                    ████████  ██
//                                   █      ████
//
//

const Image = ({
    src,
    alt,
    width,
    height,
    format,
    dpr,
    quality,
    maxHeight,
    fit,

    auto,

    zoom,
    lightboxBackgroundColor,

    noTransform, // pass this if you have a Sanity image URL that you don't want transformed
}) => {
    const [isZoomed, setIsZoomed] = useState(false)

    const handleZoomChange = useCallback((shouldZoom) => {
        setIsZoomed(shouldZoom)
    }, [])

    const url = src
    let transformedImage

    if (url.includes('cdn.sanity.io') && !noTransform) {
        if (width?.includes('em')) {
            console.error(
                `Width for Sanity images cannot be a "rem" or "em" value.`,
            )
            return null
        }
        if (height?.includes('em')) {
            console.error(
                `Height for Sanity images cannot be a "rem" or "em" value.`,
            )
            return null
        }

        transformedImage = imageTransformations({
            url,
            width,
            height,
            dpr,
            format,
            quality,
            auto,
        })
    }

    if (zoom) {
        const zoomHandler = () => {
            handleZoomChange(!isZoomed)
        }

        return (
            <Zoom isZoomed={isZoomed} onClick={zoomHandler}>
                <Img
                    src={transformedImage ? transformedImage.url : url}
                    alt={alt}
                    width={
                        width
                            ? transformedImage && transformedImage.width // if we have a transformed image, use that width: ;
                                ? `${transformedImage.width}px`
                                : width
                            : 'auto'
                    }
                    height={
                        height
                            ? transformedImage && transformedImage.height // if we have a transformed image, use that height
                                ? `${transformedImage.height}px`
                                : height
                            : 'auto'
                    }
                    fit={fit}
                    isZoomed={isZoomed}
                    zoom
                />
                {isZoomed !== false && (
                    <Lightbox lightboxBackgroundColor={lightboxBackgroundColor}>
                        <img src={url} alt={alt} />
                    </Lightbox>
                )}
            </Zoom>
        )
    }

    return (
        <Img
            src={transformedImage ? transformedImage.url : url}
            alt={alt}
            width={
                width
                    ? transformedImage && transformedImage.width // if we have a transformed image, use that width
                        ? `${transformedImage.width}px`
                        : width
                    : 'auto'
            }
            height={
                height
                    ? transformedImage && transformedImage.height // if we have a transformed image, use that height
                        ? `${transformedImage.height}px`
                        : height
                    : 'auto'
            }
            maxHeight={maxHeight ? maxHeight : 'auto'}
            fit={fit}
        />
    )
}

export default Image

const determineFit = ({ fit }) => {
    if (fit === 'cover') {
        return `
            object-fit: cover;
            width: 100%;
            height: 100%;
        `
    }
    if (fit === 'contain') {
        return `
            object-fit: contain;
            width: 100%;
            height: 100%;
        `
    }
    return `object-fit: ${fit};`
}

const Img = styled.img`
    max-width: 100%;

    width: ${({ width }) => width};
    height: ${({ height }) => height};

    ${(props) => determineFit(props)}
`

const Zoom = styled.div`
    position: relative;
    cursor: zoom-in;

    img {
        cursor: zoom-in;
    }
`

const Lightbox = styled.div`
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    padding: 4rem;
    z-index: 9999;
    cursor: zoom-out;

    background-color: ${
        ({ theme, lightboxBackgroundColor }) =>
            lightboxBackgroundColor
                ? lightboxBackgroundColor
                : theme
                ? theme.color.background
                : '#fff' // defaults to white
    };
    display: flex;
    justify-content: center;
    align-items: center;

    img {
        width: 100%;
        height: 100%;
        object-fit: contain;
        cursor: zoom-out;
    }
`
