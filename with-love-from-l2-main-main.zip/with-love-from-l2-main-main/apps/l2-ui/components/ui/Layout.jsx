import styled from 'styled-components'

import { centerContents } from '../../helpers/style'

const Layout = ({
    children,
    width,
    height,
    padding,
    margin,

    paddingTop,
    paddingRight,
    paddingBottom,
    paddingLeft,

    marginTop,
    marginRight,
    marginBottom,
    marginLeft,

    overflowY,
    center,
    hidden,

    backgroundColor,
}) => {
    return (
        <LayoutContainer
            width={width} // width of the container
            height={height} // height of the container
            //
            margin={margin} // container margin
            padding={padding} // container padding
            marginTop={marginTop} // container margin top
            marginRight={marginRight} // container margin right
            marginBottom={marginBottom} // container margin bottom
            marginLeft={marginLeft} // container margin left
            paddingTop={paddingTop} // container padding top
            paddingRight={paddingRight} // container padding right
            paddingBottom={paddingBottom} // container padding bottom
            paddingLeft={paddingLeft} // container padding left
            //
            overflowY={overflowY} // container overflow y
            center={center ? true : false} // center the contents of the container
            hidden={hidden ? true : false} // toggle the visibility of the container
            //
            backgroundColor={backgroundColor} // background color of the container
        >
            {children}
        </LayoutContainer>
    )
}

export default Layout

const LayoutContainer = styled.div`
    width: ${({ width }) => width || 'auto'};
    height: ${({ height }) => height || 'auto'};
    margin: ${({ margin }) => margin || '0'};
    padding: ${({ padding }) => padding || '0'};
    ${({ center }) => center && centerContents()};
    ${({ hidden }) => hidden && 'display: none'};

    ${({ paddingTop }) => `padding-top: ${paddingTop}`};
    ${({ paddingRight }) => `padding-right: ${paddingRight}`};
    ${({ paddingBottom }) => `padding-bottom: ${paddingBottom}`};
    ${({ paddingLeft }) => `padding-left: ${paddingLeft}`};

    ${({ marginTop }) => `margin-top: ${marginTop}`};
    ${({ marginRight }) => `margin-right: ${marginRight}`};
    ${({ marginBottom }) => `margin-bottom: ${marginBottom}`};
    ${({ marginLeft }) => `margin-left: ${marginLeft}`};

    ${({ backgroundColor }) => `background-color: ${backgroundColor}`};

    ${({ overflowY }) => overflowY && `overflow-y: scroll;`}
`
