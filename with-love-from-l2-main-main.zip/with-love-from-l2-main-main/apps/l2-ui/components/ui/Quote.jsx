import styled from 'styled-components'

import Text from './Text'

import { bp, bpR } from '../../helpers/breakpoints'

const Quote = ({
    favorit,
    inter,
    jha,
    times,
    // mono,

    fontSizeBasis, // later use this to multiple the font size by a number per breakpoint
    width,
    height,

    columns,

    children,
}) => {
    const textComponentProps = {
        favorit,
        inter,
        jha,
        times,
        // mono,

        columns,
    }

    return (
        <QuoteContainer width={width} height={height}>
            <Text
                fontSize={fontSizeBasis ? fontSizeBasis : '4rem'}
                {...textComponentProps}
            >
                {children}
            </Text>
        </QuoteContainer>
    )
}

export default Quote

export const QuoteContainer = styled.div`
    // container fills the width of it's parent element
    width: 100%;
    height: 100%;

    display: flex;
    justify-content: center;
    align-items: center;

    white-space: pre-wrap;

    & > * {
        width: calc(100% - 2rem);
        line-height: 0.95em;
        margin: 1em 0;
        font-size: 2rem;

        @media (min-width: ${bp.md}) {
            width: ${({ width }) => width || `${bpR.md - 50}px`};
            font-size: 3rem;
        }

        @media (min-width: ${bp.lg}) {
            width: ${({ width }) => width || `${bpR.lg - 50}px`};
            font-size: 4rem;
        }

        @media (min-width: ${bp.xl}) {
            width: ${({ width }) => width || `${bpR.xl - 100}px`};
        }
    }
`
