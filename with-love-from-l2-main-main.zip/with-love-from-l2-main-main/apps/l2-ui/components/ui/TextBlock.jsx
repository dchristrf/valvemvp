import BaseBlockContent from '@sanity/block-content-to-react'

import Text from './Text'

// Component to render a text block from Sanity, using our Text component for styling
//
// You can use this component by passing your blocks from your textBlock
// from Sanity to the TextBlock component, using the "blocks" prop.
//
// eg:
// <TextBlock blocks={data.yourText || []} />
//
// ⚠️ Note:
// The "blocks" prop must be an array
// (this is how Sanity returns `text`)
// More info about Sanity's `text` type is here:
// https://www.sanity.io/docs/text-type

const serializers = {
    types: {
        block(props) {
            switch (props.node.style) {
                case 'h1':
                    return <Text h1>{props.children}</Text>
                case 'h2':
                    return <Text h2>{props.children}</Text>
                case 'h3':
                    return <Text h3>{props.children}</Text>
                case 'h4':
                    return <Text h4>{props.children}</Text>
                case 'blockquote':
                    return <blockquote>{props.children}</blockquote>
                default:
                    return (
                        <Text p>
                            {props.children}
                            <br />
                        </Text>
                    )
            }
        },
    },
    marks: {
        link: (props) => (
            <a target="_blank" href={props.mark.href} rel="noreferrer">
                {props.children}
            </a>
        ),
        em: (props) => <Text jha>{props.children}</Text>,
        strong: (props) => <strong>{props.children}</strong>,
    },
}

const TextBlock = ({ blocks }) => (
    <BaseBlockContent blocks={blocks} serializers={serializers} />
)

export default TextBlock
