// import { useState, useEffect } from 'react'
import styled from 'styled-components'

// Assets from Romina
import All from './assets/All'
import Heart1 from './assets/Heart1'
import Heart2 from './assets/Heart2'
import Stars1 from './assets/Stars1'
import Stars2 from './assets/Stars2'

const SVG = ({ heart, stars, alt, color, fill, stroke, shadow }) => {
    return (
        <SVGContainer color={color} shadow={shadow} fill={fill} stroke={stroke}>
            {heart && !alt ? (
                <Heart1 />
            ) : heart && alt ? (
                <Heart2 />
            ) : stars && !alt ? (
                <Stars1 />
            ) : stars && alt ? (
                <Stars2 />
            ) : (
                <All />
            )}{' '}
        </SVGContainer>
    )
}

export default SVG

const SVGContainer = styled.div`
    svg {
        .cls-1 {
            /* stroke: ${({ stroke }) => stroke || 'none'};
            fill: ${({ fill }) => fill || 'none'}; */

            stroke: none;
            fill: ${({ fill }) => fill || 'none'};
        }
        /* filter: drop-shadow(0px 0px 10px rgba(0 0 0 / 1)); */
    }
`
