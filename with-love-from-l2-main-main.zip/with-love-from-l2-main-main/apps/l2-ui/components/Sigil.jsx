import { sigil, reactRenderer } from '@tlon/sigil-js'

const Sigil = ({ patp, size, colors }) => {
    // note: `colors` must be an array of strings
    // eg: `['black', 'white']`
    // background color is the first color in the array
    // foreground color is the second color in the array

    return (
        <>
            {sigil({
                patp,
                renderer: reactRenderer,
                size,
                colors,
            })}
        </>
    )
}

export default Sigil
