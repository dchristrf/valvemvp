module.exports = {
  bracketSpacing: true,
  jsxBracketSameLine: false,
  printWidth: 80,
  proseWrap: 'always',
  semi: true,
  singleQuote: true,
  tabWidth: 2,
  trailingComma: 'all',
  useTabs: false,
  overrides: [
    {
      files: ['*.html', '*.css', '*.scss'],
      options: {
        tabWidth: 4,
      },
    },
    {
      files: ['*.jsx'],
      options: {
        tabWidth: 4,
        semi: false,
      },
    },
    {
      files: ['*.md'],
      options: {
        tabWidth: 4,
        printWidth: 1000,
      },
    },
    {
      files: ['package*.json'],
      options: {
        printWidth: 1000,
      },
    },
    {
      files: ['*.yml'],
      options: {
        singleQuote: false,
      },
    },
  ],
};
