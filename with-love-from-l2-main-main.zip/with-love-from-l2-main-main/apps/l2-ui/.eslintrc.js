module.exports = {
  env: {
    browser: true,
    es2021: true,
    node: true,
  },
  extends: [
    'plugin:react/recommended',
    'plugin:import/recommended',
    'airbnb-base',
    'airbnb/hooks',
    'airbnb/rules/react',
    'next/core-web-vitals',
    // please keep prettier at the end
    'prettier',
  ],
  parserOptions: {
    ecmaVersion: 12,
    sourceType: 'module',
    ecmaFeatures: {
      defaultParams: true,
      jsx: true,
      spread: true,
    },
  },
  plugins: ['react'],
  rules: {
    'arrow-body-style': [0, 'as-needed'],
    'import/extensions': 'off', // Don't require extensions when importing
    'import/no-unresolved': ['off', { caseSensitive: true }],
    'max-classes-per-file': 'off',
    '@next/next/no-img-element': 'off',
    'no-nested-ternary': 'off',
    'no-unneeded-ternary': 'off',
    'no-unused-vars': 'warn',
    radix: 'off',
    'react/button-has-type': 'off',
    'react/jsx-boolean-value': 'off',
    'react/jsx-curly-brace-presence': [
      0,
      { props: 'never', children: 'always' },
    ],
    'react/jsx-props-no-spreading': 'off',
    'react/no-array-index-key': 'off',
    'react/no-unescaped-entities': 'warn',
    'react/prefer-stateless-function': 'warn',
    'react/prop-types': 'off',
    'react/react-in-jsx-scope': 'off', // next.js specific fix: Suppress errors for missing 'import React' in files for next.js
    semi: 'off',
  },
  settings: {
    react: {
      version: 'detect',
    },
    'import/extensions': ['.js', '.jsx'],
  },
};
