module.exports = {
  reactStrictMode: false,
  swcMinify: false, // https://nextjs.org/docs/messages/swc-minify-enabled
  experimental: {
    // Enable the styled-components SWC transform
    // Ref ad discussion here:
    // https://github.com/vercel/next.js/discussions/30174#discussion-3643870
    styledComponents: true,
    // Remove console logs
    // https://nextjs.org/docs/advanced-features/compiler#remove-console
    removeConsole: process.env.NODE_ENV === 'development' ? false : true,
  },
  eslint: {
    // Warning: This allows production builds to successfully complete even if
    // your project has ESLint errors.
    ignoreDuringBuilds: true,
  },
};
