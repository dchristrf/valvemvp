```bash
# install (from monorepo)
yarn

# run
yarn run dev

# build and export static HTML
yarn run build:html
```

<details><summary>Links</summary>
<p>

-   Sanity: https://github.com/sanity-io/next-sanity
-   [Next.js](https://nextjs.org/docs/getting-started)
-   [SWC](https://swc.rs) (`babel` equivalent we're using here)

</p>
</details>
