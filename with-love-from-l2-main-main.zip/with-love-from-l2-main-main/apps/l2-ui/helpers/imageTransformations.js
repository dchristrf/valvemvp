/* eslint-disable no-param-reassign */
// ImageTransformations.js purely handles image transformations for Sanity image URLs,
// mostly for Image.jsx
//
// It's been broken out of Image.jsx so it can be used elsewhere

import { bpR } from './breakpoints';

const imageTransformations = ({
  url,
  width,
  height,
  // dpr,
  format,
  quality,
  auto,
}) => {
  // remove "px" from width and height if it exists
  if (width?.includes('px')) {
    width = width.replace('px', '');
  }
  if (height?.includes('px')) {
    height = height.replace('px', '');
  }

  if (auto) {
    // dynamically set width based on the next breakpoint value
    //
    // this allows us to set image sizes dynamically, but only have
    // a few image transformations that Sanity could possibly
    // generate for each image

    let minWidthFound = false;
    Object.keys(bpR).forEach((breakpoint) => {
      //
      if (width < bpR[breakpoint] && minWidthFound === false) {
        minWidthFound = true;
        if (minWidthFound === true) {
          width = bpR[breakpoint];
        }
      }
    });
  }

  // create our transformations as URL params
  const transformFormat = format ? `fm=${format}` : `auto=format`;
  // format can be jpg, pjpg, png, or webp, otherwise uses `auto=format`,
  // which returns the image as a WEBP if the browser supports it
  // ref: https://www.sanity.io/docs/image-urls#auto-777d41f23d56
  const transformWidth = width ? `w=${width}` : null;
  const transformHeight = height ? `h=${height}` : null;
  // const transformDpr = dpr ? `dpr=${dpr}` : `dpr=auto`;
  const transformQuality = quality ? `q=${quality}` : `q=90`; //

  // create a string of our transformations
  const transforms = [
    transformWidth,
    transformHeight,
    transformFormat,
    // transformDpr, // use `window.devicePixelRatio` to build this in later maybe https://developer.mozilla.org/en-US/docs/Web/API/Window/devicePixelRatio
    transformQuality,
  ];
  const transformString = transforms.filter(Boolean).join('&');
  // `.filter(Boolean)` removes any null values from the array, and
  // join("&") joins the array with "&"

  // construct our image url with our transformations
  const transformedUrl = `${url}?${transformString}`;

  const transformedImage = {
    url: transformedUrl,
    width,
    height,
  };

  return transformedImage;
};

export default imageTransformations;
