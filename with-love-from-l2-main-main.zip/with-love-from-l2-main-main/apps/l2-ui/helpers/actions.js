// scroll to target element
export const scrollToTarget = ({ target, id, behaviour, block, inline }) => {
  // optionally just scrolls you back up to top of page if you pass "top" as target prop
  if (target === 'top') {
    window.scrollTo({ top: 0, behavior: behaviour ? behaviour : 'smooth' });
    return;
  }

  if (target) {
    // ⚠️ prop `target` must be a Ref
    // https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollIntoView
    target.current.scrollIntoView({
      behavior: behaviour ? behaviour : 'smooth', // smooth by default // ⚠️ smooth not supported in Safari
      block: block ? block : 'start', // vertical alignment, can be `start`, `center`, `end`, or `nearest` — defaults to `start`
      inline: inline ? inline : 'nearest', // horizontal alignment, can be `start`, `center`, `end`, or `nearest` — defaults to `nearest`
    });
  }

  if (id) {
    const element = document.getElementById(id);
    element.scrollIntoView({
      behavior: behaviour ? behaviour : 'smooth', // smooth by default // ⚠️ smooth not supported in Safari
      block: block ? block : 'start', // vertical alignment, can be `start`, `center`, `end`, or `nearest` — defaults to `start`
      inline: inline ? inline : 'nearest', // horizontal alignment, can be `start`, `center`, `end`, or `nearest` — defaults to `nearest`
    });
  }
};

export const consoleLog = (...args) => {
  // example
  if (process.env.NODE_ENV === 'development') {
    // eslint-disable-next-line no-console
    console.log(...args);
  }
};
