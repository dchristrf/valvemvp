// get file extension
export const fileExt = (filename) => filename.split('.').pop();

// remove file extension
export const removeFileExt = (filename) => filename.replace(/\.[^/.]+$/, '');

// generate slug from text
export const slug = (string) =>
  string
    .toLowerCase()
    .replace(/\s+/g, '-')
    .replace(/[^\w-]+/g, '');

// get random number between `min` and `max`
export const random = (min = 1, max) => {
  const num = Math.random() * (max + 1 - min) + min;
  return Math.floor(num);
};

// shuffle items in array
export const shuffle = (arr) => arr.sort(() => 0.5 - Math.random());

// sort array items alphabetically
export const alphabetical = (arr) => [...new Set(arr)];
