// // Preloading fonts
// // Inside the component that displays on load ⤵
//
// // import the Fonts component
// import Fonts from './Fonts';
// const Layout = () => (
//     <div>
//         <Head>
//             // Add the font you want to preload inside your page's <Head> ⤵
//             <link rel="preload" href={Fonts.favoritRegular.woff2} as="font"  crossorigin="anonymous"/>
//             <link rel="preload" href={Fonts.favoritInter.woff2} as="font" crossorigin="anonymous" />
//             <link rel="preload" href={Fonts.timesNow.woff2} as="font" crossorigin="anonymous" />
//             // 📄 note: don't preload fonts you don't need within the first 0.5s of page load
//         </Head>
//     </div>
// );

export const fontFiles = {
  inter: {
    regular: {
      woff2: './fonts/inter/Inter-Regular.woff2',
    },
    semiBold: {
      woff: './fonts/inter/Inter-SemiBold.woff',
      woff2: './fonts/inter/Inter-SemiBold.woff2',
    },
  },
  sourceCodePro: {
    extraLight: {
      woff2: './fonts/source-code-pro/sourcecodepro-extralight.woff2',
    },
    light: {
      woff2: './fonts/source-code-pro/sourcecodepro-light.woff2',
    },
    regular: {
      woff2: './fonts/source-code-pro/sourcecodepro-regular.woff2',
    },
    medium: {
      woff2: './fonts/source-code-pro/sourcecodepro-medium.woff2',
    },
    semiBold: {
      woff2: './fonts/source-code-pro/sourcecodepro-semibold.woff2',
    },
    bold: {
      woff2: './fonts/source-code-pro/sourcecodepro-bold.woff2',
    },
  },
  wremena: {
    light: {
      otf: './fonts/wremena.light.otf',
    },
  },
  daisywheel: {
    otf: './fonts/daisywheel.otf',
  },
};

const baseFontStack =
  '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"';

export const fonts = {
  inter: {
    regular: `inter-regular, ${baseFontStack}`,
    semiBold: `inter-semi-bold, ${baseFontStack}`,
  },
  sourceCodePro: {
    extraLight: `sourcecodepro-extralight, ${baseFontStack}`,
    light: `sourcecodepro-light, ${baseFontStack}`,
    regular: `sourcecodepro-regular, ${baseFontStack}`,
    medium: `sourcecodepro-medium, ${baseFontStack}`,
    semiBold: `sourcecodepro-semibold, ${baseFontStack}`,
    bold: `sourcecodepro-bold, ${baseFontStack}`,
  },
  wremena: {
    light: `wremena-light, ${baseFontStack}`,
  },
  daisywheel: `daisywheel, ${baseFontStack}`,
};
